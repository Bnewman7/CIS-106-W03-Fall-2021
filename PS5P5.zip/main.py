

reply = input("Do you want to continue. Yes or no ")

while reply == "Yes":

  qty = float(input("Enter Quantity"))
  price = float(input("Enter Price"))

 if extprice >= 10000:
    discount = .25
  else:
    discount = .10

  extprice = qty * price
  total = extprice + discount
  reply = input("Do you want to continue. Yes or no")

print("Exstended price", extprice)
print("discount", discount)
print("total", total) 