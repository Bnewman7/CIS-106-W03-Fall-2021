total = 0.0
tax = 0.0
def comptotal(qty, up):
  global total
  total = float(qty) * float(up)
  global tax
  tax = float(total) * 0.07
  return total,tax

print("total ", total)
qty = float(input("Enter qty"))
up = float(input("Enter up"))

comptotal(qty, up)

print("Total ", total)
print("Tax ", tax)