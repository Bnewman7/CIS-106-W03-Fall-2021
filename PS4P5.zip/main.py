
string = input("Enter Name ")
joblevel = float(input("Enter job level "))
salary = float(input("Enter Salary "))

if joblevel >= 10:
  Bonusrate = 0.25
elif joblevel >= 5 and joblevel <= 9:
  Bonusrate = 0.20
elif joblevel <= 4:
  Bonusrate = 0.10

bonus = Bonusrate * salary

print("Name ", string)
print("bonus ", bonus)