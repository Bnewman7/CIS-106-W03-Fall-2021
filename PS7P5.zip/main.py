
def tuitionowed(chours,cprice):
  tuitionowed = float(chours) * (cprice)

  if code == "I":
    cprice = 250:
  else:
    cprice = 550:
return

string = input("lastname")
chours = float(input("credit hours"))
Code = "I"

tuitionowed = (chours,cprice)
print("tuitionowed", tuitionowed)
print("lastname", string)