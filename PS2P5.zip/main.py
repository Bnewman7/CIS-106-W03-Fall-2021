# Discount Calculations

# input
Price_of_Item = float(input("enter price"))
Discount = float(input("Enter Discount"))

# Prosses
Discount_Amount = Discount * Price_of_Item
Discounted_Price = Price_of_Item - Discount_Amount

# Output
print("Discount_Amount", Discount_Amount)
print("Discounted_Price", Discounted_Price)