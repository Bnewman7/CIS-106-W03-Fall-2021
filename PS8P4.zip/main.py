
reply = input("Yes or No")
while reply == "Yes":
  
 LastName = input("LastName")
 Miles = float(input("Miles"))
  
    def milesfromdowntown(Miles,Ticketprice):

    Ticketprice = Miles
  
  

    if miles >= 30:
      Ticketprice = 12
      
     else  Miles >= 20 and Miles <= 29
     TicketPrice = 10

     else Miles >= 10 and Miles <= 19
     Ticketprice = 8

     else Miles < 10 
     ticketprice = 5

     reply = ("Yes or No")

      

print("Ticket Price",Ticketprice)

  

