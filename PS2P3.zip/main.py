# Area and Circumference

# Input
Length = float(input("Enter Length"))
Width = float(input("Enter Width"))

# Prosses
Area = Length * Width
Circumference = 2 * Width + 2 * Length

# Output
print("Area", Area)
print("Circumference", Circumference)
