
reply = input("Do you want to continue. Yes Or No")
counter = 1
while reply == "Yes":

  string = input("enter lastname")
  hours = float(input("Enter Hours"))
  payrate = float(input("enter payrate"))
  counter = counter + 1
  grosspay = hours * payrate / 12
  if hours < 40:
    thalf = payrate * 1.5
  else:
    thalf = payrate
    
  reply = input("Do you want to continue. Yes Or No")

  print("GrossPay ", grosspay)
  print("Counter", counter)
  print("LastName", string)



