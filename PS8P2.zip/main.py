reply = input("Yes or No")
while reply == "Yes":

  length= float(input("Enter Length"))
  width = float(input("Enter Width"))
  Height = float(input("Height"))

  def squarefootage (length,width,Height):
    squarefootage =  2 * float(length) * float(width) + 2 + 2 * float(length) * float(height) + 2 * float(width) * float(height) 
    
  return

gallonsofpaint = squarefootage / 50

print("gallons of paint", gallonsofpaint)