
principle = float(input("Enter Principle "))
maturity = float(input("Enter Maturity " ))

if principle >= 100000:
  intrest = 0.06
elif principle >= 50000 and principle <= 100000:
  intrest = 0.05
elif principle >= 50000 and principle <= 100000:
  intrest = 0.04
elif principle <= 50000:
  intrest = 0.02

fyi = principle * intrest

print("Principle ", principle)
print("Intrest Rate ", intrest)
print("First Year intrest", fyi)