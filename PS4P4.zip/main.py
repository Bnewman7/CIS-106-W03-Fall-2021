
tickets = float(input("Enter ticket amount"))

if tickets >= 25:
  price = 50.00
elif tickets >= 10 and tickets <= 24:
  price = 60.00
elif tickets >= 5 and tickets <= 9:
  price = 70.00
elif tickets <= 4:
  price = 75.00

total = price * tickets

print("Number of Tickets ", tickets)
print("Price ", price)
print("Total ", total)

