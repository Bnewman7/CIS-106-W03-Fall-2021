# Book Price and Shipping

bookqty = float(input("Enter Number of Books"))
bookprice = float(input("Enter Book Amount"))

price = bookqty * bookprice

if price >= 50.00:
  Shipping = 0.00
else:
  Shipping = 25.00

Total_Price = price + Shipping

print("Total Price ", Total_Price) 
print("Shipping", Shipping)