
qty = float(input("Enter quantity"))

if qty > 10000:
  price = 10.00
elif qty > 5000  or qty < 10000:
  price = 20
elif qty < 5000:
  price = 30.00

exprice = qty * price
tax = 0.07
total = exprice + tax

print("exstended price ", exprice)
print("tax", tax)
print("total" , total)
