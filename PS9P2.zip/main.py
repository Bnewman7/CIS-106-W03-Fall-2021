def examtotal(exam1,exam2,exam3):
  
  total = float(exam1) + float(exam2) + float(exam3)
  average = float(exam1) + float(exam2) + float(exam3) / 3
  
  return total,average

lastname = input("Lastname ")
exam1 = float(input("exam1 "))
exam2 = float(input("exam2 "))
exam3 = float(input("exam3 "))


total,average = examtotal(exam1,exam2,
exam3)

print("Total,average",total,average )
