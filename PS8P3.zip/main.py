
reply = "yes or no"

while reply == "yes":

  carmake = input("Car Make")
  carmodel = input("Car Model")
  ecar = input("yes or no")
  MSRP = float(input("Enter Price"))
  Percentoff = float(input("Enter Percent Off"))

  def MSRPdiscount(MSRP,Percentoff):

    float(MSRP) * float(Percentoff)
    total = MSRP - MSRPdiscount

    TaxedMSRP = total * 0.07 + total 
     
  reply = "yes or no"

print("Taxed MSRP", TaxedMSRP)
  

  



  
