#Tip Calculator

# Inputs
Meal = float(input("Amount of Meal"))
Tip = float(input("Enter Tip"))

# Prosses
Tip  = Meal * Tip

# Output
print ("Tip" , Tip )