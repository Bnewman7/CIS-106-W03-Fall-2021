
for count in range (1, 7, 2)
print(count)

for number in range (7)
print(number)

p = float(input("Price"))
r = float(input("intrest"))

for count in range (1, 5 )
i = p * r
eb = p + i
print(count" ". p, " ", eb)
p = eb