#test average

# Inputs
Last= input("enter Last Name")
S1 = float(input("enter Number"))
S2 = float(input("Enter Number"))

# prosses
average = S1 * S2 / 2

# Outputs
print ("Last Name", Last)
print ( "average of 2 scores", average)
