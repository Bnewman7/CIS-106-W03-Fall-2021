
start = float(input("Enter start value"))
stop = float(input("enter stop value"))
incr =float(input("enter incrament"))
while start <= stop:
  print("loop incrament", start)
  start = start + incr