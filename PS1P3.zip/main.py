# Miles per Gallon

# Inputs
M = float(input( "Enter Miles"))
G = float(input( "Enter Gallons"))

# Prosses
MPG = M / G

# Outputs
print ("Miles per Gallon", MPG)