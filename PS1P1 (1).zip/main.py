# Program for simple math

# Inputs
Num1 = 10
Num2 = 10

# Prosses
Sum = Num1 + Num2
Product = Num1 * Num2
Difference = Num1 - Num2

#Output

print(" Sum is ", Sum)
print("Product is ", Product)
print("Difference is", Difference)