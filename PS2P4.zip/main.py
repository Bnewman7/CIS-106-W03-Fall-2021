# Total Tuition

# Input
Last_Name = (input("Enter Last_Name"))
Credits_Taken = float(input("Enter Credits Taken"))

# Prosses
Total_Tuition = Credits_Taken * 250 + 100

# Output
print("Last_Name", Last_Name)
print("Total_Tuition", Total_Tuition)