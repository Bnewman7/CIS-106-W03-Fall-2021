string = input(" Name ")
GrossIn = float(input("Enter Gross Income"))
Dependents = float(input("Enter Dependents"))


adj = GrossIn - Dependents * 12000

if adj > 50000:
  Taxrate = adj * .20
else:
  Taxrate = adj * .10

IncomeTax = adj * Taxrate

if IncomeTax < 0:
  IncomeTax = 100
else:
  IncomeTax = IncomeTax

print("{Name", string)
print("Gross Income", GrossIn)
print(" Dependents", Dependents)
print("adjusted Gross Income" , adj)
print("IncomeTax", IncomeTax)