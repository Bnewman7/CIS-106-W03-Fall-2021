
startv = int(input("enter start value"))
stopv = int(input("enter stop value"))
incrv = int(input("enter incrament value"))

while startv <= stopv:
  print(startv)
  startv = startv + incrv
