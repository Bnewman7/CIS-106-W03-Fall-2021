# Gross pay

# Iputs
string = input("Last Name")
Hours = float(input("Hours"))
Payrate = float(input("Payrate"))

# prosses
Grosspay = Hours * Payrate

# Output
print(Grosspay, "Grosspay")