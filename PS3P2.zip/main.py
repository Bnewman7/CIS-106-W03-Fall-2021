
item = input("Enter quantity to order (A or B)")
qty = float(input("Enter Quantity to order"))

if item == "A":
  up = 10.00
else:
  up = 20.00

extprice = up * qty

print ("item ordered:", item)
print ("Quantity:", qty)
print ("Unit Price", up)
print ("Extprice:", extprice)