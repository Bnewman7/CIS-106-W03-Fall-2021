
def battingave(hits,atbats):
 battingave = float(atbats) / float(hits)
 


atbats = float(input("at bats"))
hits = float(input("hits"))

battingave = battingave(hits,atbats)
print("battingave", battingave)