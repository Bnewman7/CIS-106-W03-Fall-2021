# Tax and total

# inputs
Amountofitem = float(input("enter amount of item"))

# Prosses
Tax = Amountofitem * 0.07
total = Tax + Amountofitem

# Output
print ("Amount entered: $", Amountofitem)
print ("Tax is         $:", Tax)
print ("Total Order: $", total)