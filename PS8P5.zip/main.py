
Reply = input("Yes or No")
while reply = "Yes":
  county = input("county")
  MV = float(input("Market Value"))

  def marketvofhome(Mv,AVP):
    float(MV) * float(AVP)

    

 reply = input("Yes or No")

print("Marketvofhome", Marketvalueofhome)



    