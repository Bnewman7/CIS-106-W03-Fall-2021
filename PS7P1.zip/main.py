
def comptotal(qty, price):
 total = float(qty) + float(price)

 if total >  10000:
   total = total = 0.90
  else: 
    total = total

return

qty = float (input("quanity"))
price = float(input("price"))

total = comptotal(qty,price)
print("total is $", total)