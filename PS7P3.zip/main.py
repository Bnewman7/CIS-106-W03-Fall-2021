
def milespergallon(distance,gprice):
  
  
  milespergallon = float(distance) / float(gprice)
  

distance =float(input("Distance"))
string = (input("city"))
gprice = 2.50

milespergallon = milespergallon(distance,gprice)
print("city" , string)
print("miles per gallon",milespergallon)
