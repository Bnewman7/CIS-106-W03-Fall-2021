

def computecom(compercent,sales):

  Target = float(sales) * 0.05 + float (sales)
  total = float(sales) * float(compercent)
  if sales >= 10000:
    compercent = 0.10

  else:
    sales < 100000
    compercent = 0.05


  return Target, total

LastName = input("LastName ")
sales = float(input("Sales "))
compercent = compercent
Target,total = computecom(compercent,sales)
print ("total,target", total,Target)
