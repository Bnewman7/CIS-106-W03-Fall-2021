
def bowlscore(score1,score2,score3,handicap):
  avescore = float(score1)  + float(score2) + float(score3) / 3
  avescoreh = float(score1)  + float(score2) + float(score3) / 3 + float(handicap) 

  return avescore,avescoreh

Lastname = input("LastName ")
score1 = float(input("Score1 "))
score2 = float(input("Score2 "))
score3 = float(input("Score3 "))
handicap = float(input("Handicap "))

avescore,avescoreh = bowlscore(score1,score2,score3,handicap)
print("average score,avesoreh",avescore,avescoreh)