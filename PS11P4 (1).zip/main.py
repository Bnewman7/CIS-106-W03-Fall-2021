
def repeatShift(line):
        
  noOfChar = int(input("Enter no. of characters to print in each lines: "))
       
  noOfLine = int(input("Enter no. of lines to print: "))
        
  scrDirection = input("Enter scroll direction of Line: Right: r || Left: l -> ")

        
  shift = ""
  if scrDirection == "r":
    shift = ""
  elif scrDirection == "l":
    shift = " " * (noOfLine - 1)

    counter = 0

       
  for i in range(noOfLine):
                
   print(shift, end='')

                
  if scrDirection == "r":
   shift += " "
  elif scrDirection == "l":
   shift = shift[:-1]

                
  for j in range(noOfChar):
                       
   print(line[counter], end='')
                        
   counter = (counter + 1) % len(line)
                
   print()


if __name__ == '__main__':
        
 line = input("Enter the line of text: ")
        
 repeatShift(line)