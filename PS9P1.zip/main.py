
def disamount(qty,price,disprice):
  total = float(qty) * float(price) 
  discount = float(total) - float(disprice)
  return total,discount

qty = float(input("quantity"))
price = float(input("price"))
disprice = float(input("discount"))

total,discount = disamount(qty,price,disprice)
print("discount is $,total",discount,total)