# Appliance ConnectionResetError

string = input("Appliance Name ")
Cost = float(input("Cost of Appliance "))

if Cost > 1000.00:
  Warrenty = Cost * 0.10
else:
  Warrenty = Cost * 0.05

Total_Cost = Warrenty + Cost

print("Name of Appliance ", string)
print("Cost of Appliance ", Cost)
print("Warrenty Cost ", Warrenty)
print("Total Cost ", Total_Cost)