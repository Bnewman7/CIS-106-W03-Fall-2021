# Exstended Price

# Inputs
Quantity = float(input("Enter Quantity"))
Price_Per_Unit = float(input("Enter Price Per Unit"))
 
 
Extended_Price = Quantity * Price_Per_Unit

# Output
print("Extended_Price" , Quantity * Price_Per_Unit)


