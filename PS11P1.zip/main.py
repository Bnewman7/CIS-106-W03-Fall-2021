
name = input("enter full name:")
l = name.split()
for word in l:
  word = word.strip
  
if len(l)==1:
  print(" , please provide complete ")
else:
  print("printing your name in the format of (Lastname F)  :")
print("{} {}".format(l[1],l[0][0]))


