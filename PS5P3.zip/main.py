
count = 0

reply = input("do you wnat to caclulate averge score. Yes or No ")

while reply == "Yes":
  count = count + 1
  LastName = input("Enter Last Name ")
  score1 = float(input("Enter Score 1 "))
  score2 = float(input("Enter Score 2 "))
  avg = (score1 + score2)/2
  print(LastName , "has average of " , avg)
  reply = input("do you wnat to caclulate averge score. Yes or No ")

print("Number of students ", count)
print("average exam score ", avg)
